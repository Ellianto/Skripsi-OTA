from server import app

# TODO: Create tests in Postman
if __name__ == '__main__':
    app.run()